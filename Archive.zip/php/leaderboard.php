<!DOCTYPE html>
<html lang=en>
<head>
<meta charset=utf-8>
<title>Rewired Olympics</title>
<link href='//fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
</head>
<body>
<h1>Leaderboard</h1>
<ul>
    <li>USER 123</li>
</ul>
</body>
</html>