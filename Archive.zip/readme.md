Rewired Olympics: an unofficial Olympic top trumps game with obscure data.

# Data used

* [Data from the Guardian](http://www.guardian.co.uk/sport/series/london-2012-olympics-data). We're not really using this yet, but we should be.